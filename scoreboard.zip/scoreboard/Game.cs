﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace scoreboard
{
    public class Game
    {

        public string bat1, bat2;
        public string bowl;
        public int run;
        public int overstart(string bat, string bat2) {


            return run;
        
        }
    }
}
