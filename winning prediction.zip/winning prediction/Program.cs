﻿using System;
using System.IO;

class CricketMatchPrediction
{
    static void Main()
    {
        // Path to the text file with team information
        string filePath = "team_data.txt";

        // Ensure the file exists
        if (!File.Exists(filePath))
        {
            Console.WriteLine("Team data file not found.");
            return;
        }

        // Read data from the file
        string[] lines = File.ReadAllLines(filePath);

        // Get user input for team names
        Console.WriteLine("Enter the names of the two teams to predict (separated by comma):");
        string userInput = Console.ReadLine();
        string[] selectedTeams = userInput.Split(',');

        // Find team information for the selected teams
        TeamInfo team1 = FindTeamInfo(lines, selectedTeams[0]);
        TeamInfo team2 = FindTeamInfo(lines, selectedTeams[1]);

        if (team1 != null && team2 != null)
        {
            // Predict winning percentage
            double winningPercentageTeam1 = PredictWinningPercentage(team1, team2);
            double winningPercentageTeam2 = 100 - winningPercentageTeam1;

            // Display the predictions
            Console.WriteLine($"Predicted Winning Percentage for {team1.Name}: {winningPercentageTeam1}%");
            Console.WriteLine($"Predicted Winning Percentage for {team2.Name}: {winningPercentageTeam2}%");
        }
        else
        {
            Console.WriteLine("One or both of the entered team names were not found in the data file.");
        }
        Console.ReadKey();
    }

    static TeamInfo FindTeamInfo(string[] lines, string teamName)
    {
        foreach (var line in lines)
        {
            TeamInfo teamInfo = ExtractTeamInfo(line);
            if (teamInfo.Name.Equals(teamName, StringComparison.OrdinalIgnoreCase))
            {
                return teamInfo;
            }
        }
        return null;
    }

    static double PredictWinningPercentage(TeamInfo team1, TeamInfo team2)
    {
        double team1Score = 0;
        double team2Score = 0;

        // Compare wins
        team1Score += team1.Wins - team2.Wins;
        team2Score += team2.Wins - team1.Wins;

        // Compare losses (negative impact)
        team1Score -= team1.Losses - team2.Losses;
        team2Score -= team2.Losses - team1.Losses;

        // Compare average collector run
        team1Score += (team1.AvgCollectorRun - team2.AvgCollectorRun) * 0.1;
        team2Score += (team2.AvgCollectorRun - team1.AvgCollectorRun) * 0.1;

        // Compare average chases run
        team1Score += (team1.AvgChasesRun - team2.AvgChasesRun) * 0.1;
        team2Score += (team2.AvgChasesRun - team1.AvgChasesRun) * 0.1;

        // Compare average run rate
        team1Score += (team1.AvgRunRate - team2.AvgRunRate) * 0.2;
        team2Score += (team2.AvgRunRate - team1.AvgRunRate) * 0.2;

        // Normalize scores
        double normalizedScoreTeam1 = Sigmoid(team1Score);
        double normalizedScoreTeam2 = Sigmoid(team2Score);

        // Convert normalized scores to percentages
        double winningPercentageTeam1 = normalizedScoreTeam1 * 100;
        double winningPercentageTeam2 = normalizedScoreTeam2 * 100;

        return winningPercentageTeam1;
    }

    static TeamInfo ExtractTeamInfo(string line)
    {
        // Split the line into parts
        string[] parts = line.Split(',');

        // Parse information and create a TeamInfo object
        return new TeamInfo
        {
            Name = parts[0],
            Wins = int.Parse(parts[1]),
            Losses = int.Parse(parts[2]),
            Draws = int.Parse(parts[3]),
            AvgCollectorRun = double.Parse(parts[4]),
            AvgChasesRun = double.Parse(parts[5]),
            AvgRunRate = double.Parse(parts[6])
        };
    }

    // Sigmoid function to normalize scores
    static double Sigmoid(double x)
    {
        return 1 / (1 + Math.Exp(-x));
    }
}

class TeamInfo
{
    public string Name { get; set; }
    public int Wins { get; set; }
    public int Losses { get; set; }
    public int Draws { get; set; }
    public double AvgCollectorRun { get; set; }
    public double AvgChasesRun { get; set; }
    public double AvgRunRate { get; set; }
}
