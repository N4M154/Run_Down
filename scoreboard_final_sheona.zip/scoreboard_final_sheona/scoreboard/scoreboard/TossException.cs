﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace scoreboard
{
    
    
    //unusable for now, may need later or delete it


    public class TossException: Exception
    {
        public TossException(string message): base(message) { }
    }
}
